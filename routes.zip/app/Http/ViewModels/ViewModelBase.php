<?php

namespace App\Http\ViewModels;

class ViewModelBase {}
