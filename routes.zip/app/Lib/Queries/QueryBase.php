<?php

namespace App\Lib\Queries;

class QueryBase {}
