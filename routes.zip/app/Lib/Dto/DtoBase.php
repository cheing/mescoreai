<?php

namespace App\Lib\Dto;

class DtoBase {}
