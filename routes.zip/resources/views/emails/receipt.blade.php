<!DOCTYPE html>
<html>

<head>
    <title>Deposit Receipt</title>
</head>

<body>
    <p>Hello, {{ $username }}</p>
    <p>Your ME88 Username: {{ $me88Username }}</p>
    <p>Your registered email: {{ $userEmail }}</p>
    <p>Your receipt has been attached to this email.</p>
    <p>Thank you!</p>
</body>

</html>