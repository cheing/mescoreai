<?php

return [
    'poster' => 'images/cover-zh.jpg?v=2',
    'videoSrc' => 'video/me_ai_score_zh.mp4?v=2',
];
