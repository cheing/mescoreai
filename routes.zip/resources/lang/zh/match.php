<?php

return [
    'text_1_x_2_tips' => '1 x 2 预测',
    'text_best_tip' => '最佳预测',
    'text_correct_matches' => '正确匹配',
    'text_correct_score' => '正确比分',
    'text_date' => '日期',
    'text_finished' => '已结束',
    'text_handicap' => '让球',
    'text_match' => '比赛',
    'text_odd' => '赔率',
    'text_o_u' => '大小球',
    'text_predict_correct_rate' => '预测正确率',
    'text_time' => '时间',
    'text_tip' => '预测',
    'text_upcoming' => '即将到来',
    'text_win_rate' => '胜率',
];
