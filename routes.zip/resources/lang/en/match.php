<?php

return [
    'text_1_x_2_tips' => '1 x 2 Tips',
    'text_best_tip' => 'Best Tip',
    'text_correct_matches' => 'Correct Matches',
    'text_correct_score' => 'Correct Score',
    'text_date' => 'Date',
    'text_finished' => 'Finished',
    'text_handicap' => 'Handicap',
    'text_match' => 'Match',
    'text_odd' => 'Odd',
    'text_o_u' => 'O/U',
    'text_predict_correct_rate' => 'Predict Correct Rate',
    'text_time' => 'Time',
    'text_tip' => 'Tip',
    'text_upcoming' => 'Upcoming',
    'text_win_rate' => 'Win Rate',
    ];
