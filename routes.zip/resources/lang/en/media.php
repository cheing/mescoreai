<?php

return [
    'poster' => 'images/cover-en.jpg?v=2',
    'videoSrc' => 'video/me_ai_score_en.mp4?v=2',
    ];
